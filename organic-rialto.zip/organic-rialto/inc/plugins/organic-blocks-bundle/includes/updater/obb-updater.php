<?php
/**
 * EDD Updater Functions
 *
 * @package Organic Blocks Bundle
 * @since Organic Blocks Bundle 1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'obb_plugin_updater' ) ) {

	/**
	 * The code that compares version numbers for updates.
	 */
	function obb_plugin_updater() {

		// To support auto-updates, this needs to run during the wp_version_check cron job for privileged users.
		$doing_cron = defined( 'DOING_CRON' ) && DOING_CRON;
		if ( ! current_user_can( 'manage_options' ) && ! $doing_cron ) {
			return;
		}

		// Retrieve our license key from the DB.
		$license_key = trim( get_option( 'obb_license_key' ) );
		$status      = get_option( 'obb_license_status' );

		// Setup the updater.
		$edd_updater = new OBB_Plugin_Updater(
			OBB_OT_STORE_URL,
			__FILE__,
			array(
				'version' => OBB_CURRENT_VERSION, // Current version number, i.e. '1.0'.
				'license' => $license_key, // License key (used get_option above to retrieve from DB).
				'item_id' => OBB_PRODUCT_ID, // ID of the product.
				'author'  => 'Organic Themes', // Author of this plugin.
				'beta'    => false,
			)
		);
	}
}
add_action( 'init', 'obb_plugin_updater' );

if ( ! function_exists( 'obb_admin_menus' ) ) {

	/**
	 * Register Organic Widgets menu pages.
	 *
	 * @since 1.0.0
	 */
	function obb_admin_menus() {

		$icon_svg = 'data:image/svg+xml;base64,' . base64_encode(
			'<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="40px" height="40px" viewBox="120 10 40 40" xml:space="preserve">
			<g>
				<path fill="#a0a5aa" d="M144.128,11.221c-7.733,0-13.455,1.824-17.002,5.421c-8.137,8.252-5.41,17.112-4.38,19.634
					c0.906,2.217,2.021,3.613,2.875,4.35l2.957-2.609l-0.278-13.13l2.999,10.728l4.374-3.86l0.438-10.677l1.894,8.617l10.528-8.433
					l-8.292,10.76l8.57,1.933l-10.595,0.444l-3.776,4.422l10.614,3.049l-12.974-0.278l-2.522,2.956c0.092,0.11,0.194,0.228,0.315,0.344
					c1.9,1.938,5.897,3.889,10.54,3.889c3.257,0,8.112-0.991,12.775-5.72c8.079-8.19,4.882-25.648,3.841-30.338
					C154.816,12.222,149.721,11.221,144.128,11.221L144.128,11.221L144.128,11.221z"/>
			</g>
			</svg>'
		);

		// Add Menu Item. WP.com conditionally hide license page.
		if ( defined( 'IS_ATOMIC' ) && IS_ATOMIC && defined( 'ATOMIC_CLIENT_ID' ) && '2' === ATOMIC_CLIENT_ID && ( 'organic-stax' === get_template() || 'natural-block' === get_template() || 'restaurant-block' === get_template() || 'photographer-block' === get_template() || 'artistry' === get_template() || 'organic-rialto' === get_template() || 'organic-chrono' === get_template() ) ) {
			return;
		} else {
			add_menu_page(
				esc_html__( 'Organic Blocks', 'obb' ),
				esc_html__( 'Organic Blocks', 'obb' ),
				'manage_options',
				OBB_LICENSE_PAGE,
				'obb_license_page',
				$icon_svg,
				110
			);
		}
	}
}
add_action( 'admin_menu', 'obb_admin_menus' );

if ( ! function_exists( 'obb_license_page' ) ) {

	/**
	 * Include license screen content.
	 *
	 * @since    1.0.0
	 */
	function obb_license_page() {
		include_once plugin_dir_path( __FILE__ ) . '/admin/obb-license-page.php';
	}
}

if ( ! function_exists( 'obb_register_option' ) ) {

	/**
	 * Register license option.
	 *
	 * @since 1.0.0
	 */
	function obb_register_option() {
		// Creates our settings in the options table.
		register_setting( 'obb_license', 'obb_license_key', 'obb_sanitize_license' );
	}
}
add_action( 'admin_init', 'obb_register_option' );

if ( ! function_exists( 'obb_sanitize_license' ) ) {

	/**
	 * Sanitize license.
	 *
	 * @param array $new Update old instance.
	 * @since 1.0.0
	 */
	function obb_sanitize_license( $new ) {
		$old = get_option( 'obb_license_key' );
		if ( $old && $old != $new ) {
			delete_option( 'obb_license_status' ); // New license has been entered, so must reactivate.
		}
		return $new;
	}
}
