<?php
/**
 * Theme updater admin page notices.
 *
 * @package Organic Rialto
 * @version 1.0.0
 */

/**
 * This is a means of catching errors from the activation method above and displyaing it to the customer
 */
function organic_rialto_admin_notices() {
	if ( isset( $_GET['sl_theme_activation'] ) && ! empty( $_GET['message'] ) ) {

		switch ( $_GET['sl_theme_activation'] ) {

			case 'false':
				$message = urldecode( sanitize_text_field( $_GET['message'] ) );
				?>
				<div class="error">
					<p><?php echo wp_kses_post( $message ); ?></p>
				</div>
				<?php
				break;

			case 'true':
			default:
				break;

		}
	}
}
add_action( 'admin_notices', 'organic_rialto_admin_notices' );
