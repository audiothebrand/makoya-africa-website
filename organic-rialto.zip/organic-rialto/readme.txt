Contributors: organicthemes, itsdavidmorgan
Requires at least: 5.8
Tested up to: 6.2
Requires PHP: 7.2
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Rialto is a multi-purpose block-based theme. It is designed for the Full Site Editor.

== Description ==

Rialto is a multi-purpose block-based theme. It is designed for the Full Site Editor.

== Installation ==

1. If you don't have the <a href="https://wordpress.org/plugins/gutenberg/">the Gutenberg plugin</a> installed and activated, go to Appearance > Plugins > Add New in your admin panel and search for 'Gutenberg'. Install and activate the plugin.
2. If you don't have the <a href="https://organicthemes.com/blocks/">Organic Blocks Bundle</a> plugin installed and activated, you may acquire the plugin from your Organic Themes <a href="https://organicthemes.com/account/account-downloads/">account downloads</a>.
After downloading the plugin, go to Appearance > Plugins > Add New > Upload Plugin in the WordPress admin panel. Upload, install and activate the plugin.
3. Locate the Rialto theme on your computer. Again, you may acquire the theme from your Organic Themes <a href="https://organicthemes.com/account/account-downloads/">account downloads</a>.
4. Then, in your admin panel, go to Appearance > Themes > Add New > Upload Theme.
5. Upload, install and activate the Rialto theme.


== Copyright ==

Rialto WordPress Theme, 2021 Organic Themes
Rialto is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
